import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://mxsztuccjyukxccuzajm.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im14c3p0dWNjanl1a3hjY3V6YWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM3NTcxNDEsImV4cCI6MjA3OTMzMzE0MX0.SF6FG1r_OmdcfRN-_MaKPd0ilYpTNqot4njw4HS14RM";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Types
export interface League {
  id: string;
  name_ar: string;
  name_en: string;
  country: string;
  logo_url: string | null;
  season: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Team {
  id: string;
  name_ar: string;
  name_en: string;
  league_id: string;
  logo_url: string | null;
  venue: string | null;
  country: string | null;
  founded: number | null;
  created_at: string;
  updated_at: string;
}

export interface Match {
  id: string;
  league_id: string;
  home_team_id: string;
  away_team_id: string;
  match_date: string;
  venue: string | null;
  status: string;
  home_score: number;
  away_score: number;
  half_time_home_score: number | null;
  half_time_away_score: number | null;
  minute: number | null;
  added_time: number | null;
  is_live: boolean;
  created_at: string;
  updated_at: string;
}

export interface MatchEvent {
  id: string;
  match_id: string;
  team_id: string;
  event_type: string;
  minute: number;
  added_time: number;
  player_name_ar: string | null;
  player_name_en: string | null;
  description_ar: string | null;
  description_en: string | null;
  created_at: string;
}

export interface AdminUser {
  id: string;
  email: string;
  role: string;
  permissions: any[];
  full_name: string | null;
  last_active: string | null;
  created_at: string;
  updated_at: string;
}
