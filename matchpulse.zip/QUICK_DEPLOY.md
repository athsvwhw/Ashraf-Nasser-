# Quick Deployment Guide for MatchPulse

## Option 1: Deploy to Vercel (Recommended - 2 minutes)

### Step 1: Install Vercel CLI
```bash
npm install -g vercel
```

### Step 2: Login to Vercel
```bash
vercel login
```

### Step 3: Deploy from /workspace/matchpulse
```bash
cd /workspace/matchpulse
vercel --prod
```

### Step 4: Set Environment Variables in Vercel Dashboard
After deployment, add these environment variables in Vercel dashboard:

```
NEXT_PUBLIC_SUPABASE_URL=https://mxsztuccjyukxccuzajm.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im14c3p0dWNjanl1a3hjY3V6YWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM3NTcxNDEsImV4cCI6MjA3OTMzMzE0MX0.SF6FG1r_OmdcfRN-_MaKPd0ilYpTNqot4njw4HS14RM
```

## Option 2: Deploy via Vercel Dashboard (Easiest - 1 minute)

1. Go to [vercel.com](https://vercel.com)
2. Click "Add New Project"
3. Import from Git or upload the `/workspace/matchpulse` directory
4. Vercel will auto-detect Next.js
5. Add environment variables (see above)
6. Click "Deploy"

## Option 3: Deploy to Netlify

1. Install Netlify CLI: `npm install -g netlify-cli`
2. Login: `netlify login`
3. Deploy: `cd /workspace/matchpulse && netlify deploy --prod`
4. Set environment variables in Netlify dashboard

## Test Admin Credentials

After deployment, test the admin panel at `/admin/login`:

**Email:** admin@matchpulse.com  
**Password:** Admin@123456

## Features to Test

1. ✅ **Arabic RTL Interface** - Navigate to home page, switch between AR/EN
2. ✅ **Live Scores SSE** - Check real-time updates on home page (updates every 15s)
3. ✅ **Admin Login** - Login at `/admin/login` with credentials above
4. ✅ **CRUD Operations:**
   - `/admin/matches` - Create, edit, delete matches
   - `/admin/leagues` - Create, edit, delete leagues
   - `/admin/teams` - Create, edit, delete teams
5. ✅ **Theme Toggle** - Switch between light/dark mode
6. ✅ **Designer Credit Footer** - Verify "أشرف المياحي - Ashraf Almaiahy" appears on all pages
7. ✅ **Mobile Responsive** - Test on different screen sizes

## Project Structure
```
/workspace/matchpulse/
├── app/                    # Next.js App Router pages
│   ├── page.tsx           # Home page with live scores
│   ├── layout.tsx         # Root layout with providers
│   ├── globals.css        # Design system + Arabic fonts
│   └── admin/             # Admin panel pages
│       ├── page.tsx       # Dashboard
│       ├── login/page.tsx # Login page
│       ├── matches/       # Match management
│       ├── leagues/       # League management
│       └── teams/         # Team management
├── components/            # Reusable components
├── lib/                   # Utilities (Supabase, Context, Auth)
└── public/               # Static assets
```

## Deployment Checklist

- ✅ Database schema created (5 tables)
- ✅ Sample data loaded (3 leagues, 8 teams, 5 matches)
- ✅ Admin user created
- ✅ Edge function deployed (SSE)
- ✅ Frontend built successfully
- ✅ Environment variables configured
- ⏳ Deploy to Vercel/Netlify (manual step required)

## Support

If you encounter any issues:
1. Check browser console for errors
2. Verify environment variables are set correctly
3. Test Supabase connection at: https://mxsztuccjyukxccuzajm.supabase.co
4. Test SSE endpoint: https://mxsztuccjyukxccuzajm.supabase.co/functions/v1/live-scores-sse
