import type { Metadata } from "next";
import { Noto_Kufi_Arabic, Alexandria, Inter } from "next/font/google";
import "./globals.css";

const notoKufiArabic = Noto_Kufi_Arabic({
  variable: "--font-arabic",
  subsets: ["arabic"],
  weight: ["400", "500", "600", "700"],
});

const alexandria = Alexandria({
  variable: "--font-heading",
  subsets: ["arabic"],
  weight: ["400", "600", "700"],
});

const inter = Inter({
  variable: "--font-latin",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "MatchPulse - مباريات كرة القدم المباشرة",
  description: "منصة رياضية شاملة لمتابعة المباريات المباشرة والنتائج والإحصائيات",
  keywords: ["كرة القدم", "مباريات مباشرة", "نتائج", "sports", "football", "live scores"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body
        className={`${notoKufiArabic.variable} ${alexandria.variable} ${inter.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
