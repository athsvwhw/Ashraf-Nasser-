'use client';

import { useEffect, useState } from 'react';
import { supabase, Match, Team, League } from '@/lib/supabase';
import { AppProvider, useApp } from '@/lib/context';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import MatchCard from '@/components/MatchCard';
import { Flame, Calendar } from 'lucide-react';

type EnrichedMatch = Match & {
  league?: League;
  home_team?: Team;
  away_team?: Team;
};

function HomePage() {
  const { language } = useApp();
  const [liveMatches, setLiveMatches] = useState<EnrichedMatch[]>([]);
  const [todayMatches, setTodayMatches] = useState<EnrichedMatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateFilter, setDateFilter] = useState<'yesterday' | 'today' | 'tomorrow'>('today');

  // Fetch matches
  const fetchMatches = async () => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      let filterDate = new Date(today);
      if (dateFilter === 'yesterday') {
        filterDate.setDate(filterDate.getDate() - 1);
      } else if (dateFilter === 'tomorrow') {
        filterDate.setDate(filterDate.getDate() + 1);
      }
      
      const endDate = new Date(filterDate);
      endDate.setDate(endDate.getDate() + 1);

      // Fetch live matches
      const { data: liveData, error: liveError } = await supabase
        .from('matches')
        .select('*')
        .eq('is_live', true)
        .order('match_date', { ascending: true });

      if (liveError) throw liveError;

      // Fetch matches for selected date
      const { data: todayData, error: todayError } = await supabase
        .from('matches')
        .select('*')
        .gte('match_date', filterDate.toISOString())
        .lt('match_date', endDate.toISOString())
        .order('match_date', { ascending: true });

      if (todayError) throw todayError;

      // Enrich matches with team and league data
      const enrichMatches = async (matches: Match[]): Promise<EnrichedMatch[]> => {
        const enriched = await Promise.all(
          matches.map(async (match) => {
            const [leagueRes, homeTeamRes, awayTeamRes] = await Promise.all([
              supabase.from('leagues').select('*').eq('id', match.league_id).maybeSingle(),
              supabase.from('teams').select('*').eq('id', match.home_team_id).maybeSingle(),
              supabase.from('teams').select('*').eq('id', match.away_team_id).maybeSingle(),
            ]);

            return {
              ...match,
              league: leagueRes.data || undefined,
              home_team: homeTeamRes.data || undefined,
              away_team: awayTeamRes.data || undefined,
            };
          })
        );
        return enriched;
      };

      const enrichedLive = await enrichMatches(liveData || []);
      const enrichedToday = await enrichMatches(todayData || []);

      setLiveMatches(enrichedLive);
      setTodayMatches(enrichedToday);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching matches:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMatches();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchMatches, 30000);
    return () => clearInterval(interval);
  }, [dateFilter]);

  // Connect to SSE for real-time updates
  useEffect(() => {
    const eventSource = new EventSource(
      'https://mxsztuccjyukxccuzajm.supabase.co/functions/v1/live-scores-sse'
    );

    eventSource.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'update' && data.matches) {
        setLiveMatches(data.matches);
      }
    };

    eventSource.onerror = () => {
      console.error('SSE connection error');
      eventSource.close();
    };

    return () => {
      eventSource.close();
    };
  }, []);

  const dateButtons = [
    { value: 'yesterday', label: { ar: 'الأمس', en: 'Yesterday' } },
    { value: 'today', label: { ar: 'اليوم', en: 'Today' } },
    { value: 'tomorrow', label: { ar: 'غداً', en: 'Tomorrow' } },
  ] as const;

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 mt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-bg-base to-bg-primary py-12">
          <div className="max-w-7xl mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold font-heading mb-4">
              {language === 'ar' ? 'مباريات كرة القدم المباشرة' : 'Live Football Matches'}
            </h1>
            <p className="text-text-secondary text-lg">
              {language === 'ar' 
                ? 'تابع النتائج والأحداث لحظة بلحظة' 
                : 'Follow scores and events in real-time'}
            </p>
          </div>
        </section>

        {/* Live Matches */}
        {liveMatches.length > 0 && (
          <section className="py-12 bg-bg-primary">
            <div className="max-w-7xl mx-auto px-4">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-live/20 rounded-lg">
                  <Flame className="text-live" size={24} />
                </div>
                <h2 className="text-2xl font-bold font-heading">
                  {language === 'ar' ? 'المباريات المباشرة' : 'Live Matches'}
                </h2>
                <span className="inline-flex items-center justify-center w-8 h-8 bg-live/20 text-live rounded-full text-sm font-bold numbers">
                  {liveMatches.length}
                </span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {liveMatches.map((match) => (
                  <MatchCard key={match.id} match={match} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Date Filter */}
        <section className="py-8 bg-bg-elevated sticky top-16 z-40 border-b border-white/10">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-2 justify-center">
              {dateButtons.map((btn) => (
                <button
                  key={btn.value}
                  onClick={() => setDateFilter(btn.value)}
                  className={`
                    px-6 py-2 rounded-lg font-medium transition-all duration-200
                    ${dateFilter === btn.value
                      ? 'bg-accent-500 text-white shadow-lg'
                      : 'bg-bg-tertiary text-text-secondary hover:bg-bg-hover'
                    }
                  `}
                >
                  {btn.label[language]}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Today's Matches */}
        <section className="py-12 bg-bg-primary">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-3 mb-6">
              <Calendar size={24} className="text-accent-500" />
              <h2 className="text-2xl font-bold font-heading">
                {language === 'ar' ? 'جميع المباريات' : 'All Matches'}
              </h2>
            </div>

            {loading ? (
              <div className="text-center py-12">
                <div className="inline-block w-12 h-12 border-4 border-accent-500 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : todayMatches.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {todayMatches.map((match) => (
                  <MatchCard key={match.id} match={match} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-bg-elevated rounded-lg">
                <p className="text-text-secondary text-lg">
                  {language === 'ar' 
                    ? 'لا توجد مباريات في هذا التاريخ' 
                    : 'No matches on this date'}
                </p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default function Home() {
  return (
    <AppProvider>
      <HomePage />
    </AppProvider>
  );
}
