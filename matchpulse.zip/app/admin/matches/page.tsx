'use client';

import { useState, useEffect } from 'react';
import { supabase, Match, League, Team } from '@/lib/supabase';
import { AppProvider, useApp } from '@/lib/context';
import Link from 'next/link';
import { 
  LayoutDashboard, 
  Trophy, 
  Users, 
  Calendar,
  BarChart3,
  Settings,
  Plus,
  Edit2,
  Trash2,
  Search
} from 'lucide-react';
import MatchFormModal from '@/components/admin/MatchFormModal';
import ProtectedRoute from '@/components/admin/ProtectedRoute';
import { AuthProvider } from '@/lib/auth';

function AdminMatchesPage() {
  const { language } = useApp();
  const [matches, setMatches] = useState<(Match & { league?: League, home_team?: Team, away_team?: Team })[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingMatchId, setEditingMatchId] = useState<string | undefined>();

  useEffect(() => {
    fetchMatches();
  }, []);

  const fetchMatches = async () => {
    try {
      const { data, error } = await supabase
        .from('matches')
        .select('*')
        .order('match_date', { ascending: false });

      if (error) throw error;

      // Enrich with related data
      const enriched = await Promise.all(
        (data || []).map(async (match) => {
          const [leagueRes, homeTeamRes, awayTeamRes] = await Promise.all([
            supabase.from('leagues').select('*').eq('id', match.league_id).maybeSingle(),
            supabase.from('teams').select('*').eq('id', match.home_team_id).maybeSingle(),
            supabase.from('teams').select('*').eq('id', match.away_team_id).maybeSingle(),
          ]);

          return {
            ...match,
            league: leagueRes.data || undefined,
            home_team: homeTeamRes.data || undefined,
            away_team: awayTeamRes.data || undefined,
          };
        })
      );

      setMatches(enriched);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching matches:', error);
      setLoading(false);
    }
  };

  const deleteMatch = async (id: string) => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذه المباراة؟' : 'Are you sure you want to delete this match?')) {
      return;
    }

    try {
      const { error } = await supabase.from('matches').delete().eq('id', id);
      if (error) throw error;
      
      setMatches(matches.filter(m => m.id !== id));
      alert(language === 'ar' ? 'تم الحذف بنجاح' : 'Deleted successfully');
    } catch (error) {
      console.error('Error deleting match:', error);
      alert(language === 'ar' ? 'حدث خطأ أثناء الحذف' : 'Error deleting match');
    }
  };

  const adminLinks = [
    { href: '/admin', icon: LayoutDashboard, label: { ar: 'لوحة التحكم', en: 'Dashboard' } },
    { href: '/admin/matches', icon: Trophy, label: { ar: 'المباريات', en: 'Matches' } },
    { href: '/admin/leagues', icon: Calendar, label: { ar: 'الدوريات', en: 'Leagues' } },
    { href: '/admin/teams', icon: Users, label: { ar: 'الفرق', en: 'Teams' } },
    { href: '/admin/analytics', icon: BarChart3, label: { ar: 'التحليلات', en: 'Analytics' } },
  ];

  const filteredMatches = matches.filter(match =>
    match.home_team?.name_ar.includes(searchTerm) ||
    match.away_team?.name_ar.includes(searchTerm) ||
    match.league?.name_ar.includes(searchTerm)
  );

  return (
    <div className="min-h-screen bg-bg-primary flex">
      {/* Sidebar */}
      <aside className="w-64 bg-bg-base border-l border-white/10 flex flex-col">
        <div className="p-6 border-b border-white/10">
          <Link href="/" className="flex items-center gap-3">
            <h1 className="text-xl font-bold font-heading">
              <span className="text-accent-500">Match</span>
              <span>Pulse</span>
            </h1>
          </Link>
          <p className="text-xs text-text-tertiary mt-1">
            {language === 'ar' ? 'لوحة التحكم' : 'Admin Panel'}
          </p>
        </div>

        <nav className="flex-1 p-4">
          {adminLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`
                flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors
                ${link.href === '/admin/matches'
                  ? 'bg-bg-hover border-r-2 border-accent-500'
                  : 'hover:bg-bg-elevated'
                }
              `}
            >
              <link.icon size={20} />
              <span>{link.label[language]}</span>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <Link
            href="/"
            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-bg-elevated transition-colors"
          >
            <Settings size={20} />
            <span>{language === 'ar' ? 'العودة للموقع' : 'Back to Site'}</span>
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-heading mb-2">
              {language === 'ar' ? 'إدارة المباريات' : 'Match Management'}
            </h1>
            <p className="text-text-secondary">
              {language === 'ar' ? 'إضافة وتعديل وحذف المباريات' : 'Add, edit, and delete matches'}
            </p>
          </div>

          {/* Actions Bar */}
          <div className="bg-bg-elevated rounded-lg p-4 mb-6 flex items-center justify-between gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-text-tertiary" size={20} />
              <input
                type="text"
                placeholder={language === 'ar' ? 'البحث عن مباراة...' : 'Search matches...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg pr-10 pl-4 py-2 focus:outline-none focus:border-accent-500"
              />
            </div>
            <button
              onClick={() => {
                setEditingMatchId(undefined);
                setShowModal(true);
              }}
              className="flex items-center gap-2 bg-accent-500 hover:bg-accent-600 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              <Plus size={20} />
              {language === 'ar' ? 'إضافة مباراة' : 'Add Match'}
            </button>
          </div>

          {/* Matches Table */}
          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block w-12 h-12 border-4 border-accent-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <div className="bg-bg-elevated rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-bg-tertiary border-b border-white/10">
                  <tr>
                    <th className="px-6 py-4 text-right text-sm font-semibold">
                      {language === 'ar' ? 'الدوري' : 'League'}
                    </th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">
                      {language === 'ar' ? 'الفريق المضيف' : 'Home Team'}
                    </th>
                    <th className="px-6 py-4 text-center text-sm font-semibold">
                      {language === 'ar' ? 'النتيجة' : 'Score'}
                    </th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">
                      {language === 'ar' ? 'الفريق الضيف' : 'Away Team'}
                    </th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">
                      {language === 'ar' ? 'التاريخ' : 'Date'}
                    </th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">
                      {language === 'ar' ? 'الحالة' : 'Status'}
                    </th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">
                      {language === 'ar' ? 'الإجراءات' : 'Actions'}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredMatches.map((match, index) => (
                    <tr
                      key={match.id}
                      className={`
                        border-b border-white/10 hover:bg-bg-hover transition-colors
                        ${index % 2 === 0 ? 'bg-bg-elevated' : 'bg-bg-primary'}
                      `}
                    >
                      <td className="px-6 py-4 text-sm">
                        {match.league ? (language === 'ar' ? match.league.name_ar : match.league.name_en) : '-'}
                      </td>
                      <td className="px-6 py-4 text-sm font-medium">
                        {match.home_team ? (language === 'ar' ? match.home_team.name_ar : match.home_team.name_en) : '-'}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="numbers font-latin font-bold text-lg">
                          {match.home_score} - {match.away_score}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium">
                        {match.away_team ? (language === 'ar' ? match.away_team.name_ar : match.away_team.name_en) : '-'}
                      </td>
                      <td className="px-6 py-4 text-sm text-text-secondary">
                        {new Date(match.match_date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`
                          inline-block px-3 py-1 rounded-full text-xs font-medium
                          ${match.is_live 
                            ? 'bg-live/20 text-live' 
                            : match.status === 'finished'
                            ? 'bg-bg-tertiary text-text-secondary'
                            : 'bg-info/20 text-info'
                          }
                        `}>
                          {match.is_live 
                            ? (language === 'ar' ? 'مباشر' : 'Live')
                            : match.status === 'finished'
                            ? (language === 'ar' ? 'انتهت' : 'Finished')
                            : (language === 'ar' ? 'قادمة' : 'Upcoming')
                          }
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setEditingMatchId(match.id);
                              setShowModal(true);
                            }}
                            className="p-2 hover:bg-bg-tertiary rounded-lg transition-colors text-info"
                            title={language === 'ar' ? 'تعديل' : 'Edit'}
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            onClick={() => deleteMatch(match.id)}
                            className="p-2 hover:bg-bg-tertiary rounded-lg transition-colors text-danger"
                            title={language === 'ar' ? 'حذف' : 'Delete'}
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {filteredMatches.length === 0 && !loading && (
                <div className="text-center py-12 text-text-secondary">
                  {language === 'ar' ? 'لا توجد مباريات' : 'No matches found'}
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      <MatchFormModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingMatchId(undefined);
        }}
        onSuccess={fetchMatches}
        matchId={editingMatchId}
      />
    </div>
  );
}

export default function AdminMatches() {
  return (
    <AppProvider>
      <AuthProvider>
        <ProtectedRoute>
          <AdminMatchesPage />
        </ProtectedRoute>
      </AuthProvider>
    </AppProvider>
  );
}
