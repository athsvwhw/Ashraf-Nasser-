'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { AppProvider, useApp } from '@/lib/context';
import { AuthProvider, useAuth } from '@/lib/auth';
import { LogIn } from 'lucide-react';

function AdminLoginPage() {
  const { language } = useApp();
  const { signIn } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await signIn(email, password);
      router.push('/admin');
    } catch (err: any) {
      setError(err.message || (language === 'ar' ? 'فشل تسجيل الدخول' : 'Login failed'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg-primary flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-bg-elevated rounded-xl p-8 border border-white/10">
          {/* Logo */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold font-heading mb-2">
              <span className="text-accent-500">Match</span>
              <span>Pulse</span>
            </h1>
            <p className="text-text-secondary">
              {language === 'ar' ? 'لوحة التحكم' : 'Admin Panel'}
            </p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500 transition-colors"
                placeholder={language === 'ar' ? 'admin@example.com' : 'admin@example.com'}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'كلمة المرور' : 'Password'}
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500 transition-colors"
                placeholder={language === 'ar' ? '••••••••' : '••••••••'}
              />
            </div>

            {error && (
              <div className="bg-danger/20 border border-danger/50 rounded-lg p-3 text-sm text-danger">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-accent-500 hover:bg-accent-600 disabled:bg-accent-500/50 text-white rounded-lg px-4 py-3 font-medium transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <LogIn size={20} />
                  {language === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
                </>
              )}
            </button>
          </form>

          {/* Demo Credentials */}
          <div className="mt-6 pt-6 border-t border-white/10">
            <p className="text-xs text-text-tertiary text-center">
              {language === 'ar' ? 'للتجربة: استخدم أي بريد إلكتروني وكلمة مرور' : 'Demo: Use any email and password'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminLogin() {
  return (
    <AppProvider>
      <AuthProvider>
        <AdminLoginPage />
      </AuthProvider>
    </AppProvider>
  );
}
