'use client';

import { useState, useEffect } from 'react';
import { supabase, League } from '@/lib/supabase';
import { AppProvider, useApp } from '@/lib/context';
import { AuthProvider } from '@/lib/auth';
import ProtectedRoute from '@/components/admin/ProtectedRoute';
import LeagueFormModal from '@/components/admin/LeagueFormModal';
import Link from 'next/link';
import { LayoutDashboard, Trophy, Users, Calendar, BarChart3, Settings, Plus, Edit2, Trash2, Search } from 'lucide-react';

function AdminLeaguesPage() {
  const { language } = useApp();
  const [leagues, setLeagues] = useState<League[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingLeagueId, setEditingLeagueId] = useState<string | undefined>();

  useEffect(() => { fetchLeagues(); }, []);

  const fetchLeagues = async () => {
    const { data, error } = await supabase.from('leagues').select('*').order('name_ar');
    if (!error && data) setLeagues(data);
    setLoading(false);
  };

  const deleteLeague = async (id: string) => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد؟' : 'Are you sure?')) return;
    const { error } = await supabase.from('leagues').delete().eq('id', id);
    if (!error) fetchLeagues();
  };

  const adminLinks = [
    { href: '/admin', icon: LayoutDashboard, label: { ar: 'لوحة التحكم', en: 'Dashboard' } },
    { href: '/admin/matches', icon: Trophy, label: { ar: 'المباريات', en: 'Matches' } },
    { href: '/admin/leagues', icon: Calendar, label: { ar: 'الدوريات', en: 'Leagues' } },
    { href: '/admin/teams', icon: Users, label: { ar: 'الفرق', en: 'Teams' } },
  ];

  const filtered = leagues.filter(l => l.name_ar.includes(searchTerm) || l.name_en.includes(searchTerm));

  return (
    <div className="min-h-screen bg-bg-primary flex">
      <aside className="w-64 bg-bg-base border-l border-white/10 flex flex-col">
        <div className="p-6 border-b border-white/10">
          <Link href="/" className="flex items-center gap-3">
            <h1 className="text-xl font-bold font-heading"><span className="text-accent-500">Match</span><span>Pulse</span></h1>
          </Link>
        </div>
        <nav className="flex-1 p-4">
          {adminLinks.map((link) => (
            <Link key={link.href} href={link.href} className={`flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${link.href === '/admin/leagues' ? 'bg-bg-hover border-r-2 border-accent-500' : 'hover:bg-bg-elevated'}`}>
              <link.icon size={20} /><span>{link.label[language]}</span>
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-white/10">
          <Link href="/" className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-bg-elevated transition-colors">
            <Settings size={20} /><span>{language === 'ar' ? 'العودة للموقع' : 'Back to Site'}</span>
          </Link>
        </div>
      </aside>

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold font-heading mb-8">{language === 'ar' ? 'إدارة الدوريات' : 'League Management'}</h1>
          
          <div className="bg-bg-elevated rounded-lg p-4 mb-6 flex items-center justify-between gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-text-tertiary" size={20} />
              <input type="text" placeholder={language === 'ar' ? 'البحث...' : 'Search...'} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full bg-bg-tertiary border border-white/10 rounded-lg pr-10 pl-4 py-2 focus:outline-none focus:border-accent-500" />
            </div>
            <button onClick={() => { setEditingLeagueId(undefined); setShowModal(true); }} className="flex items-center gap-2 bg-accent-500 hover:bg-accent-600 text-white px-6 py-2 rounded-lg font-medium transition-colors">
              <Plus size={20} />{language === 'ar' ? 'إضافة دوري' : 'Add League'}
            </button>
          </div>

          {loading ? <div className="text-center py-12"><div className="inline-block w-12 h-12 border-4 border-accent-500 border-t-transparent rounded-full animate-spin"></div></div> : (
            <div className="bg-bg-elevated rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-bg-tertiary border-b border-white/10">
                  <tr>
                    <th className="px-6 py-4 text-right text-sm font-semibold">{language === 'ar' ? 'الاسم' : 'Name'}</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">{language === 'ar' ? 'البلد' : 'Country'}</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">{language === 'ar' ? 'الموسم' : 'Season'}</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold">{language === 'ar' ? 'الإجراءات' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((league, i) => (
                    <tr key={league.id} className={`border-b border-white/10 hover:bg-bg-hover ${i % 2 === 0 ? 'bg-bg-elevated' : 'bg-bg-primary'}`}>
                      <td className="px-6 py-4 font-medium">{language === 'ar' ? league.name_ar : league.name_en}</td>
                      <td className="px-6 py-4 text-text-secondary">{league.country}</td>
                      <td className="px-6 py-4 text-text-secondary ltr">{league.season}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${league.is_active ? 'bg-success/20 text-success' : 'bg-bg-tertiary text-text-tertiary'}`}>
                          {league.is_active ? (language === 'ar' ? 'نشط' : 'Active') : (language === 'ar' ? 'غير نشط' : 'Inactive')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button onClick={() => { setEditingLeagueId(league.id); setShowModal(true); }} className="p-2 hover:bg-bg-tertiary rounded-lg transition-colors text-info"><Edit2 size={16} /></button>
                          <button onClick={() => deleteLeague(league.id)} className="p-2 hover:bg-bg-tertiary rounded-lg transition-colors text-danger"><Trash2 size={16} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filtered.length === 0 && <div className="text-center py-12 text-text-secondary">{language === 'ar' ? 'لا توجد دوريات' : 'No leagues found'}</div>}
            </div>
          )}
        </div>
      </main>

      <LeagueFormModal isOpen={showModal} onClose={() => { setShowModal(false); setEditingLeagueId(undefined); }} onSuccess={fetchLeagues} leagueId={editingLeagueId} />
    </div>
  );
}

export default function AdminLeagues() {
  return <AppProvider><AuthProvider><ProtectedRoute><AdminLeaguesPage /></ProtectedRoute></AuthProvider></AppProvider>;
}
