'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { AppProvider, useApp } from '@/lib/context';
import Link from 'next/link';
import { 
  LayoutDashboard, 
  Trophy, 
  Users, 
  Calendar,
  BarChart3,
  Settings,
  TrendingUp,
  Activity,
  Eye
} from 'lucide-react';

function AdminDashboardPage() {
  const { language } = useApp();
  const [stats, setStats] = useState({
    totalMatches: 0,
    liveMatches: 0,
    totalLeagues: 0,
    totalTeams: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const [matchesRes, liveRes, leaguesRes, teamsRes] = await Promise.all([
        supabase.from('matches').select('id', { count: 'exact', head: true }),
        supabase.from('matches').select('id', { count: 'exact', head: true }).eq('is_live', true),
        supabase.from('leagues').select('id', { count: 'exact', head: true }),
        supabase.from('teams').select('id', { count: 'exact', head: true }),
      ]);

      setStats({
        totalMatches: matchesRes.count || 0,
        liveMatches: liveRes.count || 0,
        totalLeagues: leaguesRes.count || 0,
        totalTeams: teamsRes.count || 0,
      });
      setLoading(false);
    } catch (error) {
      console.error('Error fetching stats:', error);
      setLoading(false);
    }
  };

  const adminLinks = [
    { href: '/admin', icon: LayoutDashboard, label: { ar: 'لوحة التحكم', en: 'Dashboard' } },
    { href: '/admin/matches', icon: Trophy, label: { ar: 'المباريات', en: 'Matches' } },
    { href: '/admin/leagues', icon: Calendar, label: { ar: 'الدوريات', en: 'Leagues' } },
    { href: '/admin/teams', icon: Users, label: { ar: 'الفرق', en: 'Teams' } },
    { href: '/admin/analytics', icon: BarChart3, label: { ar: 'التحليلات', en: 'Analytics' } },
  ];

  const statCards = [
    {
      title: { ar: 'إجمالي المباريات', en: 'Total Matches' },
      value: stats.totalMatches,
      icon: Trophy,
      color: 'text-accent-500',
      bgColor: 'bg-accent-500/20',
    },
    {
      title: { ar: 'مباريات مباشرة', en: 'Live Matches' },
      value: stats.liveMatches,
      icon: Activity,
      color: 'text-live',
      bgColor: 'bg-live/20',
    },
    {
      title: { ar: 'الدوريات', en: 'Leagues' },
      value: stats.totalLeagues,
      icon: Calendar,
      color: 'text-info',
      bgColor: 'bg-info/20',
    },
    {
      title: { ar: 'الفرق', en: 'Teams' },
      value: stats.totalTeams,
      icon: Users,
      color: 'text-secondary-500',
      bgColor: 'bg-secondary-500/20',
    },
  ];

  return (
    <div className="min-h-screen bg-bg-primary flex">
      {/* Sidebar */}
      <aside className="w-64 bg-bg-base border-l border-white/10 flex flex-col">
        <div className="p-6 border-b border-white/10">
          <Link href="/" className="flex items-center gap-3">
            <h1 className="text-xl font-bold font-heading">
              <span className="text-accent-500">Match</span>
              <span>Pulse</span>
            </h1>
          </Link>
          <p className="text-xs text-text-tertiary mt-1">
            {language === 'ar' ? 'لوحة التحكم' : 'Admin Panel'}
          </p>
        </div>

        <nav className="flex-1 p-4">
          {adminLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`
                flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors
                ${link.href === '/admin'
                  ? 'bg-bg-hover border-r-2 border-accent-500'
                  : 'hover:bg-bg-elevated'
                }
              `}
            >
              <link.icon size={20} />
              <span>{link.label[language]}</span>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <Link
            href="/"
            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-bg-elevated transition-colors"
          >
            <Settings size={20} />
            <span>{language === 'ar' ? 'العودة للموقع' : 'Back to Site'}</span>
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-heading mb-2">
              {language === 'ar' ? 'لوحة التحكم' : 'Dashboard'}
            </h1>
            <p className="text-text-secondary">
              {language === 'ar' ? 'نظرة عامة على إحصائيات المنصة' : 'Overview of platform statistics'}
            </p>
          </div>

          {/* Stats Grid */}
          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block w-12 h-12 border-4 border-accent-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {statCards.map((card, index) => (
                <div
                  key={index}
                  className="bg-bg-elevated rounded-lg p-6 border border-white/10 hover:border-white/20 transition-colors"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${card.bgColor}`}>
                      <card.icon className={card.color} size={24} />
                    </div>
                  </div>
                  <h3 className="text-text-secondary text-sm mb-1">
                    {card.title[language]}
                  </h3>
                  <p className="text-3xl font-bold font-latin numbers">
                    {card.value}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Quick Actions */}
          <div className="bg-bg-elevated rounded-lg p-6 border border-white/10">
            <h2 className="text-xl font-bold font-heading mb-4">
              {language === 'ar' ? 'إجراءات سريعة' : 'Quick Actions'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Link
                href="/admin/matches"
                className="flex items-center gap-3 p-4 bg-bg-tertiary hover:bg-bg-hover rounded-lg transition-colors"
              >
                <Trophy size={20} className="text-accent-500" />
                <span>{language === 'ar' ? 'إدارة المباريات' : 'Manage Matches'}</span>
              </Link>
              <Link
                href="/admin/leagues"
                className="flex items-center gap-3 p-4 bg-bg-tertiary hover:bg-bg-hover rounded-lg transition-colors"
              >
                <Calendar size={20} className="text-info" />
                <span>{language === 'ar' ? 'إدارة الدوريات' : 'Manage Leagues'}</span>
              </Link>
              <Link
                href="/admin/teams"
                className="flex items-center gap-3 p-4 bg-bg-tertiary hover:bg-bg-hover rounded-lg transition-colors"
              >
                <Users size={20} className="text-secondary-500" />
                <span>{language === 'ar' ? 'إدارة الفرق' : 'Manage Teams'}</span>
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default function AdminDashboard() {
  return (
    <AppProvider>
      <AdminDashboardPage />
    </AppProvider>
  );
}
