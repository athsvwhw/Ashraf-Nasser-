'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useApp } from '@/lib/context';
import { X } from 'lucide-react';

interface LeagueFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  leagueId?: string;
}

export default function LeagueFormModal({ isOpen, onClose, onSuccess, leagueId }: LeagueFormProps) {
  const { language } = useApp();
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    name_ar: '',
    name_en: '',
    country: '',
    logo_url: '',
    season: '',
    is_active: true,
  });

  useEffect(() => {
    if (isOpen && leagueId) {
      fetchLeague();
    } else if (isOpen) {
      // Set current season as default
      const year = new Date().getFullYear();
      setFormData({
        name_ar: '',
        name_en: '',
        country: '',
        logo_url: '',
        season: `${year}/${year + 1}`,
        is_active: true,
      });
    }
  }, [isOpen, leagueId]);

  const fetchLeague = async () => {
    if (!leagueId) return;
    const { data } = await supabase.from('leagues').select('*').eq('id', leagueId).maybeSingle();
    if (data) {
      setFormData({
        name_ar: data.name_ar,
        name_en: data.name_en,
        country: data.country,
        logo_url: data.logo_url || '',
        season: data.season,
        is_active: data.is_active,
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (leagueId) {
        const { error } = await supabase.from('leagues').update(formData).eq('id', leagueId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('leagues').insert([formData]);
        if (error) throw error;
      }

      alert(language === 'ar' ? 'تم الحفظ بنجاح' : 'Saved successfully');
      onSuccess();
      onClose();
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-bg-elevated rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-bg-elevated border-b border-white/10 p-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold font-heading">
            {leagueId 
              ? (language === 'ar' ? 'تعديل الدوري' : 'Edit League')
              : (language === 'ar' ? 'إضافة دوري جديد' : 'Add New League')
            }
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-bg-hover rounded-lg transition-colors">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الاسم بالعربية' : 'Arabic Name'}
              </label>
              <input
                type="text"
                value={formData.name_ar}
                onChange={(e) => setFormData({ ...formData, name_ar: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
                placeholder="الدوري الإنجليزي الممتاز"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الاسم بالإنجليزية' : 'English Name'}
              </label>
              <input
                type="text"
                value={formData.name_en}
                onChange={(e) => setFormData({ ...formData, name_en: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500 ltr"
                placeholder="Premier League"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'البلد' : 'Country'}
              </label>
              <input
                type="text"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
                placeholder={language === 'ar' ? 'إنجلترا' : 'England'}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الموسم' : 'Season'}
              </label>
              <input
                type="text"
                value={formData.season}
                onChange={(e) => setFormData({ ...formData, season: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500 ltr"
                placeholder="2024/2025"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'رابط الشعار (URL)' : 'Logo URL'}
              </label>
              <input
                type="url"
                value={formData.logo_url}
                onChange={(e) => setFormData({ ...formData, logo_url: e.target.value })}
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500 ltr"
                placeholder="https://example.com/logo.png"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="is_active"
              checked={formData.is_active}
              onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
              className="w-5 h-5 accent-accent-500"
            />
            <label htmlFor="is_active" className="text-sm font-medium">
              {language === 'ar' ? 'دوري نشط' : 'Active League'}
            </label>
          </div>

          <div className="flex items-center gap-4 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-accent-500 hover:bg-accent-600 disabled:bg-accent-500/50 text-white rounded-lg px-6 py-3 font-medium transition-colors"
            >
              {loading 
                ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...') 
                : (language === 'ar' ? 'حفظ' : 'Save')
              }
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-bg-tertiary hover:bg-bg-hover text-text-primary rounded-lg px-6 py-3 font-medium transition-colors"
            >
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
