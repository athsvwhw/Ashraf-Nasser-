'use client';

import { useState, useEffect } from 'react';
import { supabase, League, Team } from '@/lib/supabase';
import { useApp } from '@/lib/context';
import { X } from 'lucide-react';

interface MatchFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  matchId?: string;
}

export default function MatchFormModal({ isOpen, onClose, onSuccess, matchId }: MatchFormProps) {
  const { language } = useApp();
  const [loading, setLoading] = useState(false);
  const [leagues, setLeagues] = useState<League[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  
  const [formData, setFormData] = useState({
    league_id: '',
    home_team_id: '',
    away_team_id: '',
    match_date: '',
    venue: '',
    status: 'scheduled',
    home_score: 0,
    away_score: 0,
    is_live: false,
  });

  useEffect(() => {
    if (isOpen) {
      fetchLeagues();
      fetchTeams();
      if (matchId) {
        fetchMatch();
      }
    }
  }, [isOpen, matchId]);

  const fetchLeagues = async () => {
    const { data } = await supabase.from('leagues').select('*').eq('is_active', true);
    if (data) setLeagues(data);
  };

  const fetchTeams = async () => {
    const { data } = await supabase.from('teams').select('*');
    if (data) setTeams(data);
  };

  const fetchMatch = async () => {
    if (!matchId) return;
    const { data } = await supabase.from('matches').select('*').eq('id', matchId).maybeSingle();
    if (data) {
      setFormData({
        league_id: data.league_id,
        home_team_id: data.home_team_id,
        away_team_id: data.away_team_id,
        match_date: data.match_date.slice(0, 16), // Format for datetime-local input
        venue: data.venue || '',
        status: data.status,
        home_score: data.home_score,
        away_score: data.away_score,
        is_live: data.is_live,
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const matchData = {
        ...formData,
        match_date: new Date(formData.match_date).toISOString(),
      };

      if (matchId) {
        const { error } = await supabase.from('matches').update(matchData).eq('id', matchId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('matches').insert([matchData]);
        if (error) throw error;
      }

      alert(language === 'ar' ? 'تم الحفظ بنجاح' : 'Saved successfully');
      onSuccess();
      onClose();
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-bg-elevated rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-bg-elevated border-b border-white/10 p-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold font-heading">
            {matchId 
              ? (language === 'ar' ? 'تعديل المباراة' : 'Edit Match')
              : (language === 'ar' ? 'إضافة مباراة جديدة' : 'Add New Match')
            }
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-bg-hover rounded-lg transition-colors">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الدوري' : 'League'}
              </label>
              <select
                value={formData.league_id}
                onChange={(e) => setFormData({ ...formData, league_id: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
              >
                <option value="">{language === 'ar' ? 'اختر الدوري' : 'Select League'}</option>
                {leagues.map((league) => (
                  <option key={league.id} value={league.id}>
                    {language === 'ar' ? league.name_ar : league.name_en}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'التاريخ والوقت' : 'Date & Time'}
              </label>
              <input
                type="datetime-local"
                value={formData.match_date}
                onChange={(e) => setFormData({ ...formData, match_date: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الفريق المضيف' : 'Home Team'}
              </label>
              <select
                value={formData.home_team_id}
                onChange={(e) => setFormData({ ...formData, home_team_id: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
              >
                <option value="">{language === 'ar' ? 'اختر الفريق' : 'Select Team'}</option>
                {teams.map((team) => (
                  <option key={team.id} value={team.id}>
                    {language === 'ar' ? team.name_ar : team.name_en}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الفريق الضيف' : 'Away Team'}
              </label>
              <select
                value={formData.away_team_id}
                onChange={(e) => setFormData({ ...formData, away_team_id: e.target.value })}
                required
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
              >
                <option value="">{language === 'ar' ? 'اختر الفريق' : 'Select Team'}</option>
                {teams.map((team) => (
                  <option key={team.id} value={team.id}>
                    {language === 'ar' ? team.name_ar : team.name_en}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الملعب' : 'Venue'}
              </label>
              <input
                type="text"
                value={formData.venue}
                onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
                placeholder={language === 'ar' ? 'اسم الملعب' : 'Stadium name'}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'الحالة' : 'Status'}
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
              >
                <option value="scheduled">{language === 'ar' ? 'قادمة' : 'Scheduled'}</option>
                <option value="live">{language === 'ar' ? 'مباشر' : 'Live'}</option>
                <option value="finished">{language === 'ar' ? 'انتهت' : 'Finished'}</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'نتيجة الفريق المضيف' : 'Home Score'}
              </label>
              <input
                type="number"
                min="0"
                value={formData.home_score}
                onChange={(e) => setFormData({ ...formData, home_score: parseInt(e.target.value) || 0 })}
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {language === 'ar' ? 'نتيجة الفريق الضيف' : 'Away Score'}
              </label>
              <input
                type="number"
                min="0"
                value={formData.away_score}
                onChange={(e) => setFormData({ ...formData, away_score: parseInt(e.target.value) || 0 })}
                className="w-full bg-bg-tertiary border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:border-accent-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="is_live"
              checked={formData.is_live}
              onChange={(e) => setFormData({ ...formData, is_live: e.target.checked })}
              className="w-5 h-5 accent-accent-500"
            />
            <label htmlFor="is_live" className="text-sm font-medium">
              {language === 'ar' ? 'مباراة مباشرة الآن' : 'Live match now'}
            </label>
          </div>

          <div className="flex items-center gap-4 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-accent-500 hover:bg-accent-600 disabled:bg-accent-500/50 text-white rounded-lg px-6 py-3 font-medium transition-colors"
            >
              {loading 
                ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...') 
                : (language === 'ar' ? 'حفظ' : 'Save')
              }
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-bg-tertiary hover:bg-bg-hover text-text-primary rounded-lg px-6 py-3 font-medium transition-colors"
            >
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
