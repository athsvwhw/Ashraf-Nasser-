'use client';

import { useApp } from '@/lib/context';

export default function Footer() {
  const { language } = useApp();

  return (
    <footer className="bg-bg-base border-t border-white/10 py-6 mt-auto">
      <div className="max-w-7xl mx-auto px-4 text-center text-text-tertiary text-sm">
        <p className="mb-2">
          {language === 'ar' 
            ? 'مصمم الموقع: أشرف المياحي — Ashraf Almaiahy' 
            : 'Website Designer: Ashraf Almaiahy — أشرف المياحي'}
        </p>
        <p className="flex items-center justify-center gap-4 flex-wrap">
          <a 
            href="https://wa.me/967774331072" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:text-accent-500 transition-colors"
          >
            WhatsApp: +967774331072
          </a>
          <span className="text-text-tertiary/50">|</span>
          <a 
            href="mailto:achrafalmaiahy@gmail.com"
            className="hover:text-accent-500 transition-colors"
          >
            Email: achrafalmaiahy@gmail.com
          </a>
        </p>
      </div>
    </footer>
  );
}
