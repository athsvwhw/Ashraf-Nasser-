'use client';

import Link from 'next/link';
import { useApp } from '@/lib/context';
import { Sun, Moon, Globe } from 'lucide-react';

export default function Navigation() {
  const { language, setLanguage, theme, toggleTheme } = useApp();

  const navLinks = [
    { href: '/', label: { ar: 'الرئيسية', en: 'Home' } },
    { href: '/leagues', label: { ar: 'الدوريات', en: 'Leagues' } },
    { href: '/teams', label: { ar: 'الفرق', en: 'Teams' } },
    { href: '/search', label: { ar: 'بحث', en: 'Search' } },
  ];

  return (
    <nav className="fixed top-0 w-full h-16 bg-bg-primary/95 backdrop-blur-md border-b border-white/10 z-50">
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        {/* Actions (left side in RTL) */}
        <div className="flex items-center gap-4">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-md hover:bg-bg-hover transition-colors"
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          
          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="p-2 rounded-md hover:bg-bg-hover transition-colors flex items-center gap-2"
            aria-label="Toggle language"
          >
            <Globe size={20} />
            <span className="text-sm font-medium">{language === 'ar' ? 'EN' : 'ع'}</span>
          </button>
        </div>

        {/* Center links */}
        <div className="flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-text-secondary hover:text-text-primary transition-colors relative group"
            >
              {link.label[language]}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent-500 group-hover:w-full transition-all duration-250" />
            </Link>
          ))}
        </div>

        {/* Logo (right side in RTL) */}
        <Link href="/" className="flex items-center gap-3">
          <h1 className="text-2xl font-bold font-heading">
            <span className="text-accent-500">Match</span>
            <span>Pulse</span>
          </h1>
        </Link>
      </div>
    </nav>
  );
}
