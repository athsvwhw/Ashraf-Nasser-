'use client';

import { Match, Team, League } from '@/lib/supabase';
import { useApp } from '@/lib/context';
import { Clock, MapPin } from 'lucide-react';
import Link from 'next/link';

interface MatchCardProps {
  match: Match & {
    league?: League;
    home_team?: Team;
    away_team?: Team;
  };
}

export default function MatchCard({ match }: MatchCardProps) {
  const { language } = useApp();

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString(language === 'ar' ? 'ar-EG' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Asia/Riyadh', // AST (UTC+3)
    });
  };

  const getStatusText = () => {
    if (match.is_live) {
      return language === 'ar' ? 'مباشر' : 'Live';
    }
    if (match.status === 'finished') {
      return language === 'ar' ? 'انتهت' : 'Finished';
    }
    return formatTime(match.match_date);
  };

  return (
    <Link href={`/match/${match.id}`}>
      <div 
        className={`
          bg-bg-elevated rounded-lg p-4 border transition-all duration-250
          hover:-translate-y-1 hover:shadow-lg
          ${match.is_live 
            ? 'border-l-4 border-l-accent-500 border-r-0 border-t border-b border-white/10' 
            : 'border border-white/10 hover:border-white/15'
          }
        `}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className={`
            text-xs font-medium px-2 py-1 rounded-full
            ${match.is_live 
              ? 'bg-live/20 text-live animate-pulse' 
              : 'bg-bg-tertiary text-text-secondary'
            }
          `}>
            {getStatusText()}
          </div>
          
          {match.league && (
            <div className="text-xs text-text-tertiary">
              {language === 'ar' ? match.league.name_ar : match.league.name_en}
            </div>
          )}
        </div>

        {/* Teams and Score */}
        <div className="space-y-3">
          {/* Home Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              <div className="w-8 h-8 bg-bg-tertiary rounded-full flex items-center justify-center overflow-hidden">
                {match.home_team?.logo_url ? (
                  <img src={match.home_team.logo_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-xs">🏟️</span>
                )}
              </div>
              <span className="font-medium text-text-primary">
                {match.home_team ? (language === 'ar' ? match.home_team.name_ar : match.home_team.name_en) : '...'}
              </span>
            </div>
            <span className="text-2xl font-bold numbers font-latin ml-4">
              {match.home_score}
            </span>
          </div>

          {/* Away Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              <div className="w-8 h-8 bg-bg-tertiary rounded-full flex items-center justify-center overflow-hidden">
                {match.away_team?.logo_url ? (
                  <img src={match.away_team.logo_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-xs">🏟️</span>
                )}
              </div>
              <span className="font-medium text-text-primary">
                {match.away_team ? (language === 'ar' ? match.away_team.name_ar : match.away_team.name_en) : '...'}
              </span>
            </div>
            <span className="text-2xl font-bold numbers font-latin ml-4">
              {match.away_score}
            </span>
          </div>
        </div>

        {/* Footer */}
        {match.venue && (
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2 text-xs text-text-tertiary">
            <MapPin size={14} />
            <span>{match.venue}</span>
          </div>
        )}
      </div>
    </Link>
  );
}
