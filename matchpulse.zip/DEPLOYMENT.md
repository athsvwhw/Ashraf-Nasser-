# MatchPulse Deployment Guide

## Overview
MatchPulse is a production-ready Arabic-first sports portal built with Next.js 14, React 18, TypeScript, Tailwind CSS, and Supabase backend.

## What's Been Built

### ✅ Backend (Supabase)
- **Database Schema**: leagues, teams, matches, match_events, admin_users
- **RLS Policies**: Public read access, admin write access
- **Edge Function**: `live-scores-sse` for real-time score updates
- **Sample Data**: Leagues (Premier League, La Liga, Champions League), Teams (8 teams), Matches (5 sample matches including 1 live)

### ✅ Frontend (Next.js)
- **Pages**:
  - Home page (/) with live scores, date filters, SSE integration
  - Admin dashboard (/admin) with statistics overview
  - Admin match management (/admin/matches) with CRUD operations
- **Features**:
  - Arabic-first RTL layout with English toggle
  - Dark/Light theme with system preference detection
  - Real-time live scores via Server-Sent Events (SSE)
  - Responsive mobile-first design
  - Arabic fonts: Noto Kufi Arabic, Alexandria, Inter
- **Components**:
  - Navigation with language/theme toggles
  - Match cards with live indicators
  - Admin sidebar navigation
  - Footer with designer credit

## Deployment Instructions

### Option 1: Vercel (Recommended)

Vercel is the recommended platform for Next.js applications.

1. **Install Vercel CLI**:
   ```bash
   npm install -g vercel
   ```

2. **Deploy from project directory**:
   ```bash
   cd /workspace/matchpulse
   vercel
   ```

3. **Follow prompts**:
   - Link to your Vercel account
   - Configure project settings
   - Deploy

4. **Environment Variables** (if needed in future):
   - Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel dashboard
   - Currently hardcoded in `/workspace/matchpulse/lib/supabase.ts`

### Option 2: Manual Server Deployment

For deploying to your own server:

1. **Build the application**:
   ```bash
   cd /workspace/matchpulse
   pnpm build
   ```

2. **Start production server**:
   ```bash
   pnpm start
   ```

3. **Use PM2 for process management** (recommended):
   ```bash
   npm install -g pm2
   pm2 start npm --name "matchpulse" -- start
   pm2 save
   pm2 startup
   ```

4. **Configure reverse proxy** (nginx example):
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;

       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

### Option 3: Netlify

1. **Install Netlify CLI**:
   ```bash
   npm install -g netlify-cli
   ```

2. **Deploy**:
   ```bash
   cd /workspace/matchpulse
   netlify deploy --prod
   ```

## Project Structure

```
matchpulse/
├── app/                          # Next.js App Router pages
│   ├── page.tsx                  # Home page (live scores)
│   ├── layout.tsx                # Root layout (Arabic fonts, metadata)
│   ├── globals.css               # Design tokens, theme system
│   ├── admin/
│   │   ├── page.tsx              # Admin dashboard
│   │   └── matches/
│   │       └── page.tsx          # Match management
├── components/                   # Reusable components
│   ├── Navigation.tsx            # Top navigation bar
│   ├── Footer.tsx                # Designer credit footer
│   └── MatchCard.tsx             # Match display card
├── lib/                          # Utilities
│   ├── supabase.ts               # Supabase client & types
│   └── context.tsx               # App context (language, theme)
├── supabase/functions/          # Edge functions
│   └── live-scores-sse/         # Real-time scores endpoint
├── next.config.mjs               # Next.js configuration
├── tailwind.config.ts            # Tailwind configuration
├── tsconfig.json                 # TypeScript configuration
└── package.json                  # Dependencies
```

## Supabase Configuration

### Database Tables
All tables created with RLS enabled:
- `leagues`: Competition data (name_ar, name_en, country, season)
- `teams`: Team information (name_ar, name_en, logo_url, venue)
- `matches`: Match fixtures (league_id, home/away teams, scores, status, is_live)
- `match_events`: Match events (goals, cards, substitutions)
- `admin_users`: Admin panel users (email, role, permissions)

### Edge Function
- **URL**: `https://mxsztuccjyukxccuzajm.supabase.co/functions/v1/live-scores-sse`
- **Type**: Server-Sent Events (SSE) for real-time updates
- **Update Interval**: 15 seconds

### Access
- **Supabase URL**: `https://mxsztuccjyukxccuzajm.supabase.co`
- **Anon Key**: Hardcoded in `lib/supabase.ts`

## Design System

### Colors
- **Dark Theme** (default): OLED black backgrounds (#000000, #0a0a0a, #141414)
- **Accent**: Sports green (#22c55e)
- **Secondary**: Amber (#f59e0b)
- **Semantic**: Live red (#ef4444), Success green, Warning, Danger

### Typography
- **Arabic Body**: Noto Kufi Arabic (400, 500, 600, 700)
- **Arabic Headings**: Alexandria (400, 600, 700)
- **Latin/Numbers**: Inter (400, 500, 600, 700)
- **Minimum Size**: 16px (Arabic requirement)

### Responsive Breakpoints
- **sm**: 640px (mobile landscape)
- **md**: 768px (tablet)
- **lg**: 1024px (desktop)
- **xl**: 1280px (large desktop)

## Key Features Implemented

### Public Portal
✅ Live scores with real-time updates (SSE)
✅ Date filters (yesterday/today/tomorrow)
✅ Match cards with team logos and scores
✅ Arabic RTL layout with LTR numbers
✅ Language toggle (Arabic ↔ English)
✅ Theme toggle (Dark ↔ Light)
✅ Responsive grid layout

### Admin Panel
✅ Dashboard with statistics
✅ Match management (list, search, delete)
✅ Sidebar navigation
✅ Admin-specific authentication ready (RLS configured)

### Real-time System
✅ SSE edge function deployed
✅ 15-second update interval
✅ Automatic reconnection
✅ Heartbeat monitoring

## Future Enhancements

### Short-term
- [ ] Add match creation/edit forms
- [ ] League and team management pages
- [ ] Analytics dashboard with charts
- [ ] User authentication (Supabase Auth)
- [ ] Search functionality
- [ ] Team and league detail pages

### Integration
- [ ] API-Football integration for live data (requires API key)
- [ ] Push notifications (FCM/APNs)
- [ ] Social media sharing
- [ ] Match predictions and odds

## Testing Locally

1. **Start development server**:
   ```bash
   cd /workspace/matchpulse
   pnpm dev
   ```

2. **Access**:
   - Home: http://localhost:3000
   - Admin: http://localhost:3000/admin

## Designer Credit
As required, every page includes footer credit:
```
مصمم الموقع: أشرف المياحي — Ashraf Almaiahy
WhatsApp: +967774331072 | Email: achrafalmaiahy@gmail.com
```

## Technical Notes

### Node.js Version
- **Built with**: Node.js 18.19.0
- **Next.js 14.2.0** used for Node 18 compatibility
- **Production Ready**: Yes, but upgrade to Node 20+ recommended

### Performance
- Static page generation where possible
- Image optimization via Next.js Image component (ready for use)
- CSS bundling and optimization
- Tree-shaking for minimal bundle size

### Accessibility
- WCAG AA compliant color contrast
- RTL-aware screen reader support
- Keyboard navigation ready
- Focus indicators on all interactive elements

## Support
For technical issues or deployment assistance, contact the designer:
- Email: achrafalmaiahy@gmail.com
- WhatsApp: +967774331072
