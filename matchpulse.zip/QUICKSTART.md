# MatchPulse - Quick Start Guide

## Project Summary
Complete Arabic-first sports portal with real-time live scores, admin panel, and bilingual support.

## What's Included

### Backend (Supabase)
- ✅ Database with 5 tables (leagues, teams, matches, events, admin users)
- ✅ Row-level security (RLS) policies configured
- ✅ Real-time edge function for live scores (SSE)
- ✅ Sample data pre-loaded (3 leagues, 8 teams, 5 matches)

### Frontend (Next.js)
- ✅ Home page with live match scores
- ✅ Admin dashboard with statistics
- ✅ Admin match management (view, search, delete)
- ✅ Arabic RTL ↔ English language toggle
- ✅ Dark ↔ Light theme system
- ✅ Responsive mobile-first design

## Quick Deploy (Choose One)

### 1. Vercel (Easiest - 2 minutes)
```bash
cd /workspace/matchpulse
npm install -g vercel
vercel
```
Follow the prompts to deploy. Vercel will provide a public URL.

### 2. Netlify
```bash
cd /workspace/matchpulse
npm install -g netlify-cli
netlify deploy --prod
```

### 3. Your Own Server
```bash
cd /workspace/matchpulse
pnpm build
pnpm start
# App runs on http://localhost:3000
# Configure nginx/apache as reverse proxy
```

## Test Locally First
```bash
cd /workspace/matchpulse
pnpm dev
# Open http://localhost:3000
```

## File Locations
- **Source Code**: `/workspace/matchpulse/`
- **Full Deployment Guide**: `/workspace/matchpulse/DEPLOYMENT.md`
- **Supabase Functions**: `/workspace/matchpulse/supabase/functions/`

## Supabase Dashboard
- URL: https://mxsztuccjyukxccuzajm.supabase.co
- View tables, manage data, check logs in Supabase dashboard

## Key Files to Know
- `app/page.tsx` - Home page (live scores)
- `app/admin/page.tsx` - Admin dashboard
- `app/admin/matches/page.tsx` - Match management
- `lib/supabase.ts` - Database client & types
- `components/` - Reusable components
- `app/globals.css` - Design system & themes

## Next Steps

### Immediate
1. Deploy to Vercel/Netlify
2. Test the live application
3. Access admin panel at `/admin`

### Customization
1. Add more leagues/teams via admin panel (when forms are added)
2. Integrate API-Football for real match data (requires API key)
3. Add authentication for admin panel (Supabase Auth ready)
4. Extend with more pages (team profiles, league standings, search)

## Designer Credit
Footer on every page:
```
مصمم الموقع: أشرف المياحي — Ashraf Almaiahy
WhatsApp: +967774331072
Email: achrafalmaiahy@gmail.com
```

## Support
For questions: achrafalmaiahy@gmail.com
